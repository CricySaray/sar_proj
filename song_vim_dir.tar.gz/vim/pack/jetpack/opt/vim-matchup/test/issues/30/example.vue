
<tag class="something" attr="attr and class is nicely highlighted">
    item
</tag>

<tag class="something" keyattr="attr and class has no highlight anymore">
    item
</tag>

<ul class="something" keyattr="attr and class has no highlight anymore">
    <li class="something" keyattr="linebreaks">text</li>
</ul>

<ul class="something" keyattr="attr and class has no highlight anymore">
    <li class="workaround"
        keyattr="linebreaks">text</li>
</ul>

<dl>
    <dt class='list-item'>Question 1</dt>
</dl>

